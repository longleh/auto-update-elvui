local E, L, V, P, G = unpack(ElvUI)
local _, ns = ...
local ElvUF = ns.oUF
assert(ElvUF, 'ElvUI was unable to locate oUF.')
